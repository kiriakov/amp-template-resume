// Code for search  logic //

"use strict";

const ExpertenBtn = document.getElementById('ExpertenBtn');
const ProjectBtn = document.getElementById('ProjectBtn');
const JobsBtn = document.getElementById('JobsBtn');
const BaseBtn = document.getElementById('BaseBtn');
const searchInput = document.getElementById('searchInput');
const searchBtnHref = document.getElementById('searchBtnHref');

// Variables for selection Links (without search input)
const hrefExperten = 'https://www.gulp.de/gulp2/g/spezialisten?showFreelancers=true&showEmployees=true';
const hrefProject = 'https://www.gulp.de/gulp2/g/projekte';
const hrefJobs = 'https://www.gulp.de/gulp2/g/jobs';
const hrefBase = 'https://www.gulp.de/knowledge-base?scope=kb&query=';

// Placeholders for different selected item:
const PlaceholderExperten = 'Stichwortsuche nach Experten, z.B. Java, SAP, ...';
const PlaceholderProject = 'Stichwortsuche nach Projekten, z.B. Java, SAP, ...';
const PlaceholderJobs = ' Stichwortsuche nach Jobs, z.B. Java, SAP, ...';
const PlaceholderBase = 'Suche in der Knowledge Base, z.B. SAP, Stundensatz, ...';


// Experten without search value //

    ExpertenBtn.addEventListener('click', () => {
        searchBtnHref.setAttribute('href', hrefExperten);
        searchInput.value = '';
        searchBtnHref.className = '';
        searchBtnHref.classList.add('Experten');
    });

// Project without search value //

ProjectBtn.addEventListener('click', () => {
    searchBtnHref.setAttribute('href', hrefProject);
    searchInput.value = '';
    searchBtnHref.className = '';
    searchBtnHref.classList.add('Project');
});

// Jobs without search value //

JobsBtn.addEventListener('click', () => {
    searchBtnHref.setAttribute('href', hrefJobs);
    searchInput.value = '';
    searchBtnHref.className = '';
    searchBtnHref.classList.add('Jobs');
});

// Knowledge Base without search value //

BaseBtn.addEventListener('click', () => {
    searchBtnHref.setAttribute('href', hrefBase);
    searchInput.value = '';
    searchBtnHref.className = '';
    searchBtnHref.classList.add('Base');
});

// Link  with search value

searchInput.addEventListener('input', () => {
    if(searchBtnHref.classList.contains('Project')) {
        searchBtnHref.setAttribute('href', `https://www.gulp.de/gulp2/g/projekte?query=${searchInput.value}`);
    }
    else if(searchBtnHref.classList.contains('Jobs')) {
        searchBtnHref.setAttribute('href', `https://www.gulp.de/gulp2/g/jobs?query=${searchInput.value}`);
    }
    else if(searchBtnHref.classList.contains('Base')) {
        searchBtnHref.setAttribute('href', `https://www.gulp.de/knowledge-base?scope=kb&query=${searchInput.value}`);
    }
    else if(searchBtnHref.classList.contains('Experten')) {
        searchBtnHref.setAttribute('href', `https://www.gulp.de/gulp2/g/spezialisten?query=${searchInput.value}&showFreelancers=true&showEmployees=true
`);
    }
});


// Changing of Placeholder

ProjectBtn.addEventListener('click', () => {
    searchInput.placeholder = PlaceholderProject;
});

JobsBtn.addEventListener('click', () => {
    searchInput.placeholder = PlaceholderJobs;
});

ExpertenBtn.addEventListener('click', () => {
    searchInput.placeholder = PlaceholderExperten;
});

BaseBtn.addEventListener('click', () => {
    searchInput.placeholder = PlaceholderBase;
});








