const btn = document.getElementById('checkbox-profile');
const btn1 = document.getElementById('checkbox-reference');

const expandSection = document.getElementById('profile-section');
const expandSection1 = document.getElementById('reference-section');

btn.addEventListener('click', () => {
    if (!btn.classList.contains("checked") && !expandSection.classList.contains("checked-expand")) {
        btn1.classList.remove("checked");
        expandSection1.classList.remove("checked-expand");
        btn1.classList.add("un-checked");
        expandSection1.classList.add("un-checked");
        btn.classList.toggle("checked");
    }

});

btn1.addEventListener('click', () => {
    if (!btn1.classList.contains("checked") && !expandSection1.classList.contains("checked-expand")) {
        btn.classList.remove("checked");
        expandSection.classList.remove("checked-expand");
        btn1.classList.toggle("checked");
        expandSection1.classList.toggle("checked-expand");

    }
    if (btn1.classList.contains("un-checked") && expandSection1.classList.contains("un-checked")) {
        btn1.classList.remove("un-checked");
        expandSection1.classList.remove("un-checked");
    }

});



